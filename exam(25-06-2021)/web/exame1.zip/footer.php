<!-- ======= Footer ======= -->

<footer>
       <section id="foot">
           <div class="foot-sec">
               <div class="container">
                  <div class="row foot-row">
                      <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                          <div class="foot-img foot">
                               <h3>Excellent coaching</h3>
                               <div class="add">
                                 <i class="fas fa-map-marker-alt"></i>
                                 <p>Utkarsh Classes & Edutech Pvt Ltd, Vyas Bhawan, 1st A Road, Sardarpura, Jodhpur Rajasthan, 342001</p>
                               </div>
                               <div class="phone"><i class="fas fa-phone"></i>
                                 <a href="tel:8769840062">+91 8769840062 </a>   
                               </div>
                               <div class="email"><i class="fas fa-envelope"></i>
                                  <a href="mailto:test@gmail.com">test@gmail.com</a>
                               </div>
                          </div>
                          
                      </div>
                       <div class="col-xl-2 col-lg-2 col-md-6 col-sm-12 col-12">
                          <div class="foot-img foot-sec">
                               <h3>QUICK LINKS</h3>
                               <p>
                                    <a href="#" >About Us</a>
                                    <a href="#" >English News</a>
                                    <a href="#" >Hindi News</a>
                                    <a href="#" >Career</a>
                                    <a href="#" >Contact Us</a>
                               </p>
                          </div>
                          
                      </div>
                       <div class="col-xl-2 col-lg-2 col-md-6 col-sm-12 col-12">
                          <div class="foot-img foot-three">
                              <h3>SUPPORT</h3>
                               <p>
                                  <a href="#"> Student Support</a>
                                  <a href="#"> FAQ's</a>
                                  <a href="#"> Current Affairs</a>
                                  <a href="#"> Blog Hindi</a>
                                  <a href="#"> Blog English</a>
                               </p>
                          </div>
                         
                      </div>
                       <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                          <div class="foot-img">
                              <h3>JOIN US ON</h3>
                              <ul>
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fab fa-instagram"></i></a></li>
                                <li><a href="#"><i class="fab fa-telegram-plane"></i></a></li>
                                <li><a href="#"><i class="fab fa-youtube"></i></a></li>
                                
                              </ul>
                               <h4>
                                  DOWNLOAD OUR APP
                               </h4>
                               <p>Ebooks, Test Preparation, Video Lectures</p>
                               <div class="app-foot">
                                 <a href="#"><img src="assets/img/app.png"></a>
                                 <a href="#"><img src="assets/img/app1.png"></a>
                               </div>
                          </div>
                          
                      </div>
                   </div>   
               </div>
           </div>
           <div class="foot-bootom">
                <div class="container">
                     <div class="row foo-bot">
                           <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                              <div class="foo-left">
                                 <p>
                                     © Copyright 2021 Excellent coaching. All rights reserved.
                                 </p>
                              </div>
                           </div>
                           <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                               <div class="foo-right">
                                  <p>
                                      <a href="#">Privacy Policy</a>
                                      <a href="#">Refund Policy</a>
                                      <a href="#">Terms & Conditions</a>
                                  </p>
                              </div>
                           </div>
                     </div>
                </div>
           </div>
       </section>
 </footer>



<script src="assets/vendor/jquery/jquery.min.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js">    
</script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js">    
</script>
<script src="assets/js/aos.js"></script>
 <script>
      AOS.init({
        easing: 'ease-in-out-sine'
      });
</script>
 

<script type="text/javascript">
    function openCity(evt, cityName) {
  // Declare all variables
  var i, tabcontent, tablinks;

  // Get all elements with class="tabcontent" and hide them
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }

  // Get all elements with class="tablinks" and remove the class "active"
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }

  // Show the current tab, and add an "active" class to the button that opened the tab
  document.getElementById(cityName).style.display = "block";
  evt.currentTarget.className += " active";
}
</script>


  
</body>

</html>

<?php include 'header.php';?>
 <section id="banner">     
          <div id="demo" class="carousel slide" data-ride="carousel">
              <!-- Indicators -->
              <ul class="carousel-indicators">
                <li data-target="#demo" data-slide-to="0" class="active"></li>
                <li data-target="#demo" data-slide-to="1"></li>
                <li data-target="#demo" data-slide-to="2"></li>
              </ul>
              
              <!-- The slideshow -->
              <div class="carousel-inner">
                <div class="carousel-item active">
                  <img src="assets/img/banner1.png" alt="Los Angeles" width="1100" height="500">
                  <div class="carousel-caption">
                    <!--<p>WELCOME TO</p>
                   <h1>Excellent Coaching</h1> -->   
                 </div>
                </div>
                <div class="carousel-item">
                  <img src="assets/img/banner2.png" alt="Chicago" width="1100" height="500">
                  <div class="carousel-caption">
                    <!--<p>WELCOME TO</p>
                   <h1>Excellent Coaching</h1> -->
                 </div>
                </div>
                <div class="carousel-item">
                <img src="assets/img/banner3.png" alt="New York" width="1100" height="500">
                  <div class="carousel-caption">
                    <!--<p>WELCOME TO</p>
                   <h1>Excellent Coaching</h1> -->
                 </div>
                </div>

                <div class="carousel-item">
                <img src="assets/img/banner4.png" alt="New York" width="1100" height="500">
                  <div class="carousel-caption">
                    <!--<p>WELCOME TO</p>
                   <h1>Excellent Coaching</h1> -->   
                 </div>
                </div>

              </div>
              
              <!-- Left and right controls -->
              <a class="carousel-control-prev" href="#demo" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
              </a>
              <a class="carousel-control-next" href="#demo" data-slide="next">
                <span class="carousel-control-next-icon"></span>
              </a>
            </div>
  </section>
<!-- =====================Courises=========================== -->
   <section id="course">
       <div class="container">
          <div class="course-main">
              <div class="cour-title">
                  <h3>All Course </h3>
                  <p></p>
              </div>
              <div class="couse-tab">
                  <div class="tab">
                    <button class="tablinks active" onclick="openCity(event, 'Bank')">Bank</button>
                    <button class="tablinks" onclick="openCity(event, 'SSC')">SSC</button>
                    <button class="tablinks" onclick="openCity(event, 'Railways')">Railways
                   </button>
                   <button class="tablinks" onclick="openCity(event, 'Police')">Police
                   </button>
                   <button class="tablinks" onclick="openCity(event, 'Teaching')">Teaching
                   </button>
                    <button class="tablinks" onclick="openCity(event, 'State')">State Level
                   </button>

                    </div>

                    <!-- Tab content -->
                    <div id="Bank" class="tabcontent"  style="display:block;">
                      <h3>Bank</h3>
                      <p>If you’re an individual looking for growth and success. Financial institutions are typically the best bait a student should play as this is an industry which always increases the growth graph. If you think you have the capability of being trustworthy and you attain a certain sense of responsibility vouching for great heights, the banking sector is for you. And when you think about a career in the banking sector, you should think about collaborating with Mahendras. Afterall, the best careers require the best guidance.</p>
                      <div class="tab-con-links">
                        <ul>
                         <li> <a href="#">Video Courses</a></li>
                         <li> <a href="#">Live Classes</a></li>
                         <li> <a href="#">Branch Admission</a></li>
                         <li> <a href="#">Online Test Series</a></li>
                         <li> <a href="#">E-Books</a></li>
                         <li> <a href="#">Publication</a></li>
                        </ul>
                      </div>
                    </div>

                    <div id="SSC" class="tabcontent">
                      <h3>SSC</h3>
                      <p>If you’re an individual looking for growth and success. Financial institutions are typically the best bait a student should play as this is an industry which always increases the growth graph. If you think you have the capability of being trustworthy and you attain a certain sense of responsibility vouching for great heights, the banking sector is for you. And when you think about a career in the banking sector, you should think about collaborating with Mahendras. Afterall, the best careers require the best guidance.</p>
                      <div class="tab-con-links">
                        <ul>
                         <li> <a href="#">Video Courses</a></li>
                         <li> <a href="#">Live Classes</a></li>
                         <li> <a href="#">Branch Admission</a></li>
                         <li> <a href="#">Online Test Series</a></li>
                         <li> <a href="#">E-Books</a></li>
                         <li> <a href="#">Publication</a></li>
                        </ul>
                      </div>
                    </div>

                    <div id="Railways" class="tabcontent">
                      <h3>Railways</h3>
                      <p>If you’re an individual looking for growth and success. Financial institutions are typically the best bait a student should play as this is an industry which always increases the growth graph. If you think you have the capability of being trustworthy and you attain a certain sense of responsibility vouching for great heights, the banking sector is for you. And when you think about a career in the banking sector, you should think about collaborating with Mahendras. Afterall, the best careers require the best guidance.</p>
                      <div class="tab-con-links">
                        <ul>
                         <li> <a href="#">Video Courses</a></li>
                         <li> <a href="#">Live Classes</a></li>
                         <li> <a href="#">Branch Admission</a></li>
                         <li> <a href="#">Online Test Series</a></li>
                         <li> <a href="#">E-Books</a></li>
                         <li> <a href="#">Publication</a></li>
                        </ul>
                      </div>
                    </div>

                    <div id="Police" class="tabcontent">
                      <h3>Police</h3>
                      <p>If you’re an individual looking for growth and success. Financial institutions are typically the best bait a student should play as this is an industry which always increases the growth graph. If you think you have the capability of being trustworthy and you attain a certain sense of responsibility vouching for great heights, the banking sector is for you. And when you think about a career in the banking sector, you should think about collaborating with Mahendras. Afterall, the best careers require the best guidance.</p>
                      <div class="tab-con-links">
                        <ul>
                         <li> <a href="#">Video Courses</a></li>
                         <li> <a href="#">Live Classes</a></li>
                         <li> <a href="#">Branch Admission</a></li>
                         <li> <a href="#">Online Test Series</a></li>
                         <li> <a href="#">E-Books</a></li>
                         <li> <a href="#">Publication</a></li>
                        </ul>
                      </div>
                    </div>

                    <div id="Teaching" class="tabcontent">
                      <h3>Teaching</h3>
                      <p>If you’re an individual looking for growth and success. Financial institutions are typically the best bait a student should play as this is an industry which always increases the growth graph. If you think you have the capability of being trustworthy and you attain a certain sense of responsibility vouching for great heights, the banking sector is for you. And when you think about a career in the banking sector, you should think about collaborating with Mahendras. Afterall, the best careers require the best guidance.</p>
                      <div class="tab-con-links">
                        <ul>
                         <li> <a href="#">Video Courses</a></li>
                         <li> <a href="#">Live Classes</a></li>
                         <li> <a href="#">Branch Admission</a></li>
                         <li> <a href="#">Online Test Series</a></li>
                         <li> <a href="#">E-Books</a></li>
                         <li> <a href="#">Publication</a></li>
                        </ul>
                      </div>
                    </div>

                    <div id="State" class="tabcontent">
                      <h3>State</h3>
                     <p>If you’re an individual looking for growth and success. Financial institutions are typically the best bait a student should play as this is an industry which always increases the growth graph. If you think you have the capability of being trustworthy and you attain a certain sense of responsibility vouching for great heights, the banking sector is for you. And when you think about a career in the banking sector, you should think about collaborating with Mahendras. Afterall, the best careers require the best guidance.</p>
                      <div class="tab-con-links">
                        <ul>
                         <li> <a href="#">Video Courses</a></li>
                         <li> <a href="#">Live Classes</a></li>
                         <li> <a href="#">Branch Admission</a></li>
                         <li> <a href="#">Online Test Series</a></li>
                         <li> <a href="#">E-Books</a></li>
                         <li> <a href="#">Publication</a></li>
                        </ul>
                      </div>
                    </div>
              </div>
          </div>
       </div>
   </section>
<!-- ========================our key ================================= -->
<section id="our-key">
    <div class="container">
      
      <div class="our-key-main">
              <div class="our-title">
                   <h4>EXPLORE AMAZING FEATURES</h4>
                   <h2>Our key offerings</h2>
              </div>
              
        </div>

       <div class="row">
            <div class="col-lg-4 col-md-4 col-sm-12">
                <div class="our-key-con">
                  <div class="our-key-con-img">
                       <div class="our-key-img">
                           <p><i class="fas fa-video"></i></p>
                       </div>
                       <div class="our-key-con-title">
                           <h3>Quality Video Lectures</h3>
                           <p>Top of the line faculty having an enriched experiance of years will teach you in an organized way for effective and effecient understanding</p>
                       </div>
                  </div>
              </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="our-key-con">
                  <div class="our-key-con-img">
                       <div class="our-key-img">
                          <p> <i class="fas fa-book-reader"></i></p>
                       </div>
                       <div class="our-key-con-title">
                           <h3>Online Assessments</h3>
                           <p>You can evaluate your level of preparations by participating in live tests, quizzes along with video solutions substantiated by proper explanations.</p>
                       </div>
                  </div>
              </div>

            </div>
            <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="our-key-con">
                  <div class="our-key-con-img">
                       <div class="our-key-img">
                          <p> <i class="fas fa-clipboard"></i></p>
                       </div>
                       <div class="our-key-con-title">
                           <h3>Pathbreaking Features</h3>
                           <p>For quick revision make your own custom flash cards & MCQ ,Audio feature for less data consumption ,Detailed video explanation for each question in Quiz & Test.</p>
                       </div>
                  </div>
              </div>
            </div>
       </div>

        
    </div>
</section>
<section id="in-home">
   <div class="container">
     <div class="video-home">
             <h2>Latest Videos</h2>
                                <!-- Grid row -->
<div class="row">

  <!-- Grid column -->
  <div class="col-lg-4 col-md-6 mb-4 col-sm-12">

   <video class="video-fluid z-depth-1"  loop controls muted>
  <source src="https://mdbootstrap.com/img/video/Sail-Away.mp4" type="video/mp4" />
</video>

  </div>
  <!-- Grid column -->

  <!-- Grid column -->
  <div class="col-lg-4 col-md-6 mb-4 col-sm-12">

   <video class="video-fluid z-depth-1"  loop controls muted>
  <source src="https://mdbootstrap.com/img/video/Sail-Away.mp4" type="video/mp4" />
</video>

  </div>
  <!-- Grid column -->

  <!-- Grid column -->
  <div class="col-lg-4 col-md-6 mb-4 col-sm-12">

    <video class="video-fluid z-depth-1"  loop controls muted>
      <source src="https://mdbootstrap.com/img/video/Sail-Away.mp4" type="video/mp4" />
    </video>

  </div>
  <!-- Grid column -->
  <!-- Grid column -->
  <div class="col-lg-4 col-md-6 mb-4 col-sm-12">

   <video class="video-fluid z-depth-1"  loop controls muted>
      <source src="https://mdbootstrap.com/img/video/Sail-Away.mp4" type="video/mp4" />
    </video>

  </div>

   <!-- Grid column -->
  <div class="col-lg-4 col-md-6 mb-4 col-sm-12">

   <video class="video-fluid z-depth-1"  loop controls muted>
  <source src="https://mdbootstrap.com/img/video/Sail-Away.mp4" type="video/mp4" />
</video>

  </div>
  <!-- Grid column -->

  <!-- Grid column -->
  <div class="col-lg-4 col-md-6 mb-4 col-sm-12">

   <video class="video-fluid z-depth-1"  loop controls muted>
  <source src="https://mdbootstrap.com/img/video/Sail-Away.mp4" type="video/mp4" />
</video>

  </div>
  <!-- Grid column -->

  <div class="mor-but">
    <a href="#">More Videos</a>
  </div>

</div>

        </div>


   </div>

   
</section>
<!---================================================= -->
<section id="ebook">
  <div class="container">
        <div class="video-home">
             <h2>Latest Ebooks</h2>
        </div>
        <div class="ebok-main row">
            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebok-four">
                  <img src="assets/img/img_avatar.png" alt="Avatar" class="image">
                  <div class="overlay">
                    <div class="text">
                       <a href="assets/img/ssc.pdf" download>
                           Download
                       </a>
                    </div>
                  </div>
                </div>
            </div> 
            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebok-four">
                  <img src="assets/img/img_avatar.png" alt="Avatar" class="image">
                  <div class="overlay">
                    <div class="text">
                       <a href="assets/img/ssc.pdf" download>
                           Download
                       </a>
                    </div>
                  </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebok-four">
                  <img src="assets/img/img_avatar.png" alt="Avatar" class="image">
                  <div class="overlay">
                    <div class="text">
                       <a href="assets/img/ssc.pdf" download>
                           Download
                       </a>
                    </div>
                  </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebok-four">
                  <img src="assets/img/img_avatar.png" alt="Avatar" class="image">
                  <div class="overlay">
                    <div class="text">
                       <a href="assets/img/ssc.pdf" download>
                           Download
                       </a>
                    </div>
                  </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebok-four">
                  <img src="assets/img/img_avatar.png" alt="Avatar" class="image">
                  <div class="overlay">
                    <div class="text">
                       <a href="assets/img/ssc.pdf" download>
                           Download
                       </a>
                    </div>
                  </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebok-four">
                  <img src="assets/img/img_avatar.png" alt="Avatar" class="image">
                  <div class="overlay">
                    <div class="text">
                       <a href="assets/img/ssc.pdf" download>
                           Download
                       </a>
                    </div>
                  </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebok-four">
                  <img src="assets/img/img_avatar.png" alt="Avatar" class="image">
                  <div class="overlay">
                    <div class="text">
                       <a href="assets/img/ssc.pdf" download>
                           Download
                       </a>
                    </div>
                  </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebok-four">
                  <img src="assets/img/img_avatar.png" alt="Avatar" class="image">
                  <div class="overlay">
                    <div class="text">
                       <a href="assets/img/ssc.pdf" download>
                           Download
                       </a>
                    </div>
                  </div>
                </div>
            </div>
            
        </div>
        <div class="mor-but">
          <a href="#">More Videos</a>
        </div>
  </div>
</section>
<!-- top selected============================= -->
 <section id="academic">
    <div class="partaners">
         <div class="container">
                <h1> Top Selected Students </h1>
                <div class="top-st row">
            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebbok-con">
                     <div class="ebbok-img">
                        <img src="assets/img/sd.jpg">
                     </div>
                     <div class="ebbok-tt">
                          <h3>Sandeep Pandey</h3>
                          <h4>BSF</h4>
                     </div>
                 </div>
            </div> 
            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebbok-con">
                     <div class="ebbok-img">
                        <img src="assets/img/sd.jpg">
                     </div>
                     <div class="ebbok-tt">
                          <h3>Sandeep Pandey</h3>
                          <h4>BSF</h4>
                     </div>
                 </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebbok-con">
                     <div class="ebbok-img">
                        <img src="assets/img/sd.jpg">
                     </div>
                     <div class="ebbok-tt">
                          <h3>Sandeep Pandey</h3>
                          <h4>BSF</h4>
                     </div>
                 </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebbok-con">
                     <div class="ebbok-img">
                        <img src="assets/img/sd.jpg">
                     </div>
                     <div class="ebbok-tt">
                          <h3>Sandeep Pandey</h3>
                          <h4>BSF</h4>
                     </div>
                 </div>
            </div>
            
            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebbok-con">
                     <div class="ebbok-img">
                        <img src="assets/img/sd.jpg">
                     </div>
                     <div class="ebbok-tt">
                          <h3>Sandeep Pandey</h3>
                          <h4>BSF</h4>
                     </div>
                 </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebbok-con">
                     <div class="ebbok-img">
                        <img src="assets/img/sd.jpg">
                     </div>
                     <div class="ebbok-tt">
                          <h3>Sandeep Pandey</h3>
                          <h4>BSF</h4>
                     </div>
                 </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebbok-con">
                     <div class="ebbok-img">
                        <img src="assets/img/sd.jpg">
                     </div>
                     <div class="ebbok-tt">
                          <h3>Sandeep Pandey</h3>
                          <h4>BSF</h4>
                     </div>
                 </div>
            </div>

            <div class="col-lg-3 col-md-3 col-sm-6">
                 <div class="ebbok-con">
                     <div class="ebbok-img">
                        <img src="assets/img/sd.jpg">
                     </div>
                     <div class="ebbok-tt">
                          <h3>Sandeep Pandey</h3>
                          <h4>BSF</h4>
                     </div>
                 </div>
            </div>

        </div>            
                  
         </div>
         
    </div> 
 </section>
<!-- ========================================================= -->

<section class="wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
  <div class="container padding-25px-all">
    <div class="row  hover-option4 blog-post-style3"> 
     
      <div class="grid-item col-12 col-md-6 col-lg-6 md-margin-30px-bottom text-center text-md-left wow fadeInUp" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeInUp;">
        <div class="bg-light-gray border shadow">
          <div class="padding-0px-all sm-padding-0px-all box-style-1">
            <h5 class="s2blue">Latest Vacancies </h5>
            <div class="marj">
            <marquee  scrollamount="2" scrolldelay="5" direction="up" onmouseover="this.stop()" onmouseout="this.start()">
            <ul class="p-0 list-style-10">
                                          <li class="text-extra-dark-gray text-medium"><i class="fa fa-hand-o-right text-extra-dark-gray" aria-hidden="true"></i><a href="https://www.winnersinstitute.in/sbi-clerk-notification-out-not/" class="text-extra-dark-gray"><span>SBI Clerk Notification Out Not</span></a></li>
                            <li class="text-extra-dark-gray text-medium"><i class="fa fa-hand-o-right text-extra-dark-gray" aria-hidden="true"></i><a href="https://www.winnersinstitute.in/sbi-apprentice-recruitment-2020-notification-out/" class="text-extra-dark-gray"><span>SBI Apprentice Recruitment 2020 Notification Out</span></a></li>
                            <li class="text-extra-dark-gray text-medium"><i class="fa fa-hand-o-right text-extra-dark-gray" aria-hidden="true"></i><a href="https://www.winnersinstitute.in/sbi-po-2020-notification-out/" class="text-extra-dark-gray"><span>SBI PO 2020 Notification Out</span></a></li>
                            <li class="text-extra-dark-gray text-medium"><i class="fa fa-hand-o-right text-extra-dark-gray" aria-hidden="true"></i><a href="https://www.winnersinstitute.in/ssc-chsl-102-examination-2020-notification-released/" class="text-extra-dark-gray"><span>SSC CHSL (10+2) Examination, 2020 Notification Released</span></a></li>
                            <li class="text-extra-dark-gray text-medium"><i class="fa fa-hand-o-right text-extra-dark-gray" aria-hidden="true"></i><a href="https://www.winnersinstitute.in/upsessb-tgt-pgt-recruitment-exam-notification-released/" class="text-extra-dark-gray"><span>UPSESSB TGT, PGT Recruitment Exam Notification Released</span></a></li>
                            <li class="text-extra-dark-gray text-medium"><i class="fa fa-hand-o-right text-extra-dark-gray" aria-hidden="true"></i><a href="https://www.winnersinstitute.in/ibps-so-2021-22-notification-released/" class="text-extra-dark-gray"><span>IBPS SO 2021-22 Notification Released</span></a></li>
                            <li class="text-extra-dark-gray text-medium"><i class="fa fa-hand-o-right text-extra-dark-gray" aria-hidden="true"></i><a href="https://www.winnersinstitute.in/uco-bank-so-recruitment-2020/" class="text-extra-dark-gray"><span>UCO Bank SO Recruitment 2020</span></a></li>
                            <li class="text-extra-dark-gray text-medium"><i class="fa fa-hand-o-right text-extra-dark-gray" aria-hidden="true"></i><a href="https://www.winnersinstitute.in/ssc-stenographer-grade-c-d-notification-2020-out/" class="text-extra-dark-gray"><span>SSC Stenographer Grade ‘C’ &amp; ‘D’ Notification 2020 Out</span></a></li>
                          </ul>
            </marquee>
          </div>
          </div>
        </div>
      </div>
      <div class="grid-item col-12 col-md-6 col-lg-6 text-center text-md-left wow fadeInUp" data-wow-delay="0.4s" style="visibility: visible; animation-delay: 0.4s; animation-name: fadeInUp;">
        <div class="bg-light-gray border shadow">
          <div class="padding-0px-all sm-padding-0px-all box-style-1">
            <h5 class="s2blue">UPCOMING</h5>
            <div class="marj">
            <marquee  scrollamount="2" scrolldelay="5" direction="up" onmouseover="this.stop()" onmouseout="this.start()">
                        <div class="batch">
              <div class="testimonial-info-2 text-extra-dark-gray text-medium font-weight-400 text-inherit padding-10px-bottom"><a href="https://www.winnersinstitute.in/student-zone/upcoming/" class="text-extra-dark-gray">Reasoning Foundation Online Batch</a></div>
              <div class="date"><span class="post-author text-small text-medium-gray text-uppercase d-block margin-10px-bottom sm-margin-5px-bottom"><i class="fa fa-calendar"></i> 15-06-21 &nbsp;&nbsp;|&nbsp;&nbsp; <i class="fa fa-clock-o"></i>  &nbsp;&nbsp;|&nbsp;&nbsp; <i class="fa fa-map-marker "></i> Indore</span></div>
              <div class="separator-line-horrizontal-full bg-medium-gray margin-20px-tb"></div>
            </div>
                        <div class="batch">
              <div class="testimonial-info-2 text-extra-dark-gray text-medium font-weight-400 text-inherit padding-10px-bottom"><a href="https://www.winnersinstitute.in/student-zone/upcoming/" class="text-extra-dark-gray">Science Foundation Online Batch</a></div>
              <div class="date"><span class="post-author text-small text-medium-gray text-uppercase d-block margin-10px-bottom sm-margin-5px-bottom"><i class="fa fa-calendar"></i> 15-06-21 &nbsp;&nbsp;|&nbsp;&nbsp; <i class="fa fa-clock-o"></i>  &nbsp;&nbsp;|&nbsp;&nbsp; <i class="fa fa-map-marker "></i> Indore</span></div>
              <div class="separator-line-horrizontal-full bg-medium-gray margin-20px-tb"></div>
            </div>
                        <div class="batch">
              <div class="testimonial-info-2 text-extra-dark-gray text-medium font-weight-400 text-inherit padding-10px-bottom"><a href="https://www.winnersinstitute.in/student-zone/upcoming/" class="text-extra-dark-gray">Banking Foundation Complete Online Course</a></div>
              <div class="date"><span class="post-author text-small text-medium-gray text-uppercase d-block margin-10px-bottom sm-margin-5px-bottom"><i class="fa fa-calendar"></i> 01-07-21 &nbsp;&nbsp;|&nbsp;&nbsp; <i class="fa fa-clock-o"></i>  &nbsp;&nbsp;|&nbsp;&nbsp; <i class="fa fa-map-marker "></i> Indore</span></div>
              <div class="separator-line-horrizontal-full bg-medium-gray margin-20px-tb"></div>
            </div>
                        </marquee>
                      </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>




<!--====================Exams Covered================================== -->
<section id="ex-coverd">
    <div class="container">
        <div class="ex-coverd-main">
            <div class="ex-coverd-title">
                <h3>Exams Covered</h3>
            </div>
            <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-6">
                    
                      <div class="ex-coverd-con">
                      <img src="assets/img/ibps-2.png">
                      <h3>IBPS PO</h3>
                  
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="ex-coverd-con">
                      <img src="assets/img/ibps-2.png">
                      <h3>IBPS CLERK</h3>
                  
                    </div>
                </div>


                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="ex-coverd-con">
                      <img src="assets/img/ibps-2.png">
                      <h3>IBPS RRB</h3>
                  
                    </div>
                </div>

                <div class="col-lg-3 col-md-3 col-sm-6">
                    <div class="ex-coverd-con">
                      <img src="assets/img/ibps-2.png">
                      <h3>IBPS RRB CLERK</h3>
                  
                    </div>
                </div>


                
            </div>
        </div>
    </div>
</section>
<!--=============our other ================================= -->

<section id="our-add">
  <div class="container">
      <div class="our-add-main">
          <div class="our-add-main-title">
              <h3>Our Additional Material</h3>
          </div>
          <div class="row">
              <div class="col-lg-2 com-md-4 col-sm-12">
                  <div class="our-add-con">
                      <img src="assets/img/syllabus-new.png">
                      <h3>Syllabus</h3>
                  </div>
              </div>

              <div class="col-lg-2 com-md-4 col-sm-12">
                  <div class="our-add-con">
                      <img src="assets/img/news-new.png">
                      <h3>E-News</h3>
                  </div>
              </div>

              <div class="col-lg-2 com-md-4 col-sm-12">
                  <div class="our-add-con">
                      <img src="assets/img/question-new.png">
                      <h3>Question Bank</h3>
                  </div>
              </div>

              <div class="col-lg-2 com-md-4 col-sm-12">
                  <div class="our-add-con">
                      <img src="assets/img/current-affairs-new.png">
                      <h3>Current Affairs</h3>
                  </div>
              </div>

              <div class="col-lg-2 com-md-4 col-sm-12">
                  <div class="our-add-con">
                      <img src="assets/img/vocabulary-new.png">
                      <h3>Daily Vocabulary</h3>
                  </div>
              </div>

              <div class="col-lg-2 com-md-4 col-sm-12">
                  <div class="our-add-con">
                      <img src="assets/img/e-mica-new.png">
                      <h3>Competition Booster</h3>
                  </div>
              </div>
          </div>
      </div>
  </div>
</section>

<?php include 'footer.php';?>
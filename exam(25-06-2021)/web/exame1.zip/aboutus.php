
<?php include 'header.php';?>
<!--===================== End Header ===================-->
<section id="course-sg" style="background-image: url(assets/img/bank-po.jpg);" class="back-bg">
   
</section>

<!-- ==================== COURS content======================= -->
<section id="course-content">
  <div class="container">
      <div class="row ab-botom">
           <div class="col-lg-7 col-md-7 col-sm-12">
               <div class="cour-left">
                   <h3>OVERVIEW</h3>
                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>
                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>          
                  
               </div>
           </div>
           <div class="col-lg-5 col-md-5 col-sm-12">
               <div class="cour-right ">
                   <img src="assets/img/overview.jpg" class="ab-img">
               </div>
           </div>
          </div>
          <div class="row ab-botom">
           <div class="col-lg-5 col-md-5 col-sm-12">
               <div class="cour-right ">
                   <img src="assets/img/overview.jpg" class="ab-img">
               </div>
           </div>  

           <div class="col-lg-7 col-md-7 col-sm-12">
               <div class="cour-left">
                   <h3>ABOUT DIRECTOR</h3>
                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>
                   <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum</p>          
                  
               </div>
           </div>
      </div>

       <div class="row ab-botom">
           <div class="col-12 miss-title"><h3>MISSION & VISION</h3></div>
           <div class="col-lg-4 col-md-4 col-sm-12">
               <div class="miss">
                     <img src="assets/img/mission.jpg">
                     <h3>OUR MISSION</h3>
                     <p>We strive to provide our students with an academic foundation that will enable them to clear competitive exams of their choice Like MPPSC, SSC, BANKING, VYAPAM and other Central/State government jobs as well as to succeed in those careers.</p>
               </div>
           </div>
           <div class="col-lg-4 col-md-4 col-sm-12">
               <div class="miss">
                     <img src="assets/img/vision.jpg">
                     <h3>OUR VISION</h3>
                     <p>Our vision is to develop well rounded, confident and responsible individuals who aspire to achieve their full potential. We will do this by providing a welcoming, happy, safe, and supportive learning environment in which everyone is equal and all achievements are celebrated.</p>
               </div>
           </div>
           <div class="col-lg-4 col-md-4 col-sm-12">
               <div class="miss">
                     <img src="assets/img/strenght.jpg">
                     <h3>OUR STATEMENT</h3>
                     <p>“Sarvada Vijay” says Dream Believe and achieve reflects our understanding and beliefs. We aim to ensure that the students at our institute are provided with high-quality learning experiences based on a broad and balanced curriculum.</p>
               </div>
           </div>

          </div>


  </div>
</section>
<!-- =====================Courises=========================== -->

<!-- ========================our key ================================= -->

<!--====================Exams Covered================================== -->

<!--=============our other ================================= -->



<!-- ======= Footer ======= -->

<?php include 'footer.php';?>
 <!DOCTYPE html>

<html lang="en">
  <head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1.0" name="viewport" />
  <title>Excellent coaching</title>
  <meta content="" name="description" />
  <meta content="" name="keywords" />
  <!--<link href="assets/img/favicon.png" rel="icon" />
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon" />-->
  <link rel="preconnect" href="https://fonts.gstatic.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
        <!-- Vendor CSS Files -->
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
<link href="assets/vendor/icofont/icofont.min.css" rel="stylesheet" />

<link rel="stylesheet" href="assets/css/aos.css" />
<link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet" />
<link href="assets/vendor/venobox/venobox.css" rel="stylesheet" />
<link href="assets/vendor/aos/aos.css" rel="stylesheet" />

<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
<link href="assets/css/style.css" rel="stylesheet" />

 </head>
    <body>

        <!-- ======= Top Bar ======= -->
 <div class="top-bar" id="topbar">
     <div class="container">
        <div class="row top-row">
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 top-bar-left">
                 <i class="fas fa-user"></i>
                 <span class="mail-span"> 
                    <a href="signup.php">Register</a> 
                </span>
                <i class="fas fa-unlock-alt"></i>
                <span class="tel-span"><a href="login.php"> Login</a></span>
          </div>
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 top-bar-right ">
              <!-- <a href="#"><i class="fab fa-google-play"></i>Download App</a>
             <a href="#"><i class="fas fa-search"></i></a>
              <a href="#"><i class="fas fa-shopping-cart"></i></a> -->
          </div>
         </div>
     </div>     
  </div>
 


        <!-- ======= Header ======= -->

<header id="header" class="">
    <div class="container d-flex align-items-center">
        <h1 class="logo mr-auto">
          <a href="./" class="scrollto">
            <!--<img src="./assets/img/brand-logo.png" alt="" srcset=""/>-->
             <h3>Excellent coaching</h3>
           </a>
        </h1>       
    <nav class="nav-menu d-none d-lg-block">
        <ul> 
           <li ><a href="index.php">Home</a> </li>

           <li class="drop-down"><a href="#">Exams </a>
            <ul>              
                <li class="drop-down"><a href="#">Banking & Insurance</a>
                     <ul>
                         <li class="drop-down"><a href="#">Bank PO</a>
                            <ul>
                              <li><a href="#">IBPS PO</a></li>
                              <li><a href="#">IBPS RRB</a></li>                       
                           </ul>
                         </li> 

                         <li class="drop-down"><a href="#">Bank SO</a>
                            <ul>
                              <li><a href="#">IBPS SO</a></li>               
                           </ul>
                         </li>

                         <li class="drop-down"><a href="#">Bank Clerk</a>
                            <ul>
                              <li><a href="#">IBPS Clerk</a></li>
                              <li><a href="#">SBI Clerk</a></li>
                              <li><a href="#">RRB Clerk</a></li>               
                           </ul>
                         </li>

                         <li class="drop-down"><a href="#">NABARD</a>
                            <ul>
                              <li><a href="#">NABARD Grade A</a></li>             
                           </ul>
                         </li>

                         <li class="drop-down"><a href="#">RBI</a>
                            <ul>
                              <li><a href="#">RBI ASSISTANT</a></li>
                              <li><a href="#">RBI Grade B</a></li>
                              <li><a href="#">RBI Office Attendant</a></li>            
                           </ul>
                         </li>

                         <li class="drop-down"><a href="#">NRA CET</a>
                            <ul>
                              <li><a href="#">NRA CET</a></li>            
                           </ul>
                         </li>

                     </ul>
                </li>

                  <li class="drop-down"><a href="#">SSC </a>
                  <ul>                      
                      <li><a href="#">SSC CGL</a></li>
                      <li><a href="#">SSC CHSL</a></li>
                      <li><a href="#">SSC MTS</a></li>
                      <li><a href="#">SSC Stenographer</a></li>  
                  </ul>
                 </li>

                 <li class="drop-down"><a href="#">Railways </a>
                  <ul>                      
                      <li><a href="#">RRB NTPC</a></li>                        
                  </ul>
                 </li>

                 <li class="drop-down"><a href="#">Police </a>
                  <ul>                      
                      <li><a href="#">Delhi Police Constable</a></li>
                  </ul>
                 </li>

                 <li class="drop-down"><a href="#">State Level Exams  </a>
                  <ul>                      
                      <li><a href="#">UPSSSC-Lekhpal</a></li>
                      <li><a href="#">UPSSSC-RO ARO</a></li>
                  </ul>
                 </li>



                      
                    </ul>

                  </li> 

            

           

            <li ><a href="aboutus.php">About Us</a> </li>
           
            <li><a href="contactus.php ">Contact Us</a></li>

           

        </ul>

    </nav>

                <!-- .nav-menu -->

            </div>

</header>

<!--===================== End Header ===================-->
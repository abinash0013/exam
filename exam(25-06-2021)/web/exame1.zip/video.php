<?php include 'header.php';?>
<!--===================== End Header ===================-->
<section id="course-sg" style="background-image: url(assets/img/bank-po.jpg);" class="back-bg">
   
</section>

<!-- ==================== COURS content======================= -->

<!-- ========================our key ================================= -->
<section id="cour-mid " class="livclass">
    <div class="container">
        <div class="ssc-ma">
             <p><i class="fas fa-chevron-left"></i> SSC Exam</p>
             <h3>Chapters for SSC Exams </h3>
        </div>

    </div>
</section>
<!-- =====================Courises=========================== -->


<!--====================Exams Covered================================== -->
<section id="quiz">
  <div class="container">
     <div class="row quizes">
         

         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
             <div class="quz-main">
                <div class="quz-img">
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>


         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
             <div class="quz-main">
                <div class="quz-img">
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>


         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
             <div class="quz-main">
                <div class="quz-img">
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>


         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
             <div class="quz-main">
                <div class="quz-img">
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>


         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
             <div class="quz-main">
                <div class="quz-img">
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>


     </div>
  </div>
</section>
<!--=============our other ================================= -->



<!-- ======================================= -->

<!-- ======= Footer ======= -->
<?php include 'footer.php';?>
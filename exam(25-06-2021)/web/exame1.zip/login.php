<?php include 'header.php';?>
<!--===================== End Header ===================-->
<section id="log-in">
    <div class="container">
        <div class="log-main">
            <form action="/action_page.php" >
              <div class="login-con">
                <h1>Login</h1>
               
                <hr>

                <label for="email"><b>Email</b></label>
                <input type="text" placeholder="Enter Email" name="email" required>

                <label for="psw"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="psw" required>


                <div class="clearfix">                 
                  <button type="submit" class="login">Login</button>
                </div>
              </div>
            </form>
        </div>
    </div>
</section>

<!-- ==================== COURS content======================= -->

<!--=============our other ================================= -->



<!-- ======= Footer ======= -->
<?php include 'footer.php';?>
<?php include 'header.php';?>
<!--===================== End Header ===================-->


<!-- ==================== COURS content======================= -->

<!-- ========================our key ================================= -->
<section id="cour-mid" class="sol">
    <div class="container">        
         <div class="solu-titl">
             <i class="fas fa-chevron-left"></i> <h3>Solutions</h3>
         </div>
    </div>
</section>
<!-- =====================Courises=========================== -->


<!--====================Exams Covered================================== -->
<section id="solu">
  <div class="container">
         <div class="sol-t2">
            <h3>Choose Section :</h3>
            <form>
                <select>
                    <option>History of Ancient India</option>
                    <option>History of Ancient India 1</option>
                    <option>History of Ancient India 2</option>
                    <option>History of Ancient India 3</option>
                    <option>History of Ancient India 4</option>
                    <option>History of Ancient India 5</option>
                    <option>History of Ancient India 7</option>
                    <option>History of Ancient India 8</option>
                </select>
            </form>
         </div>
  </div>
</section>
<!--=============our other ================================= -->

<section class="accord">
    <div class="container">
         <div class="acc-main">
               <div class="accordion">
                   <div class="ac-top ">
                       <h3>Q.5</h3> <h4>Un-attepmt</h4>
                   </div>
                   <div class="ac-down">
                    <p>____scheme has been intro-duced by the Central Government of provide equal priamry education to all budding children across India.</p>
                   </div>
               </div>

                <div class="panel">
                  
                  <div class="panel-con">
                     <p><span>A. Gram Uday Se Bharat Uday Abhiyan</span></p>
                     <p><span>B. Pradhan Mantri Ujjwala Yojana</span></p>
                     <p><span>C. Pradhan Mantri Surakshit Matritva Yojana</span></p>
                     <p><span>D. Vidyanjali Yojana</span></p>

                     <div class="expl">
                         <h3>Explanation</h3>
                         <ul>
                            <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s. </li>
                            <li>When an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </li><li>
                            It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages.</li> <li>
                            More recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</li>
                         </ul>
                     </div>
                  </div>
                </div>

                <button class="accordion">Section 2</button>
                <div class="panel">
                  <p>Lorem ipsum...</p>
                </div>

                <button class="accordion">Section 3</button>
                <div class="panel">
                  <p>Lorem ipsum...</p>
                </div>
         </div>
    </div>
</section>

<!-- ======================================= -->
<style type="text/css">
    /* Style the buttons that are used to open and close the accordion panel */
.accord .accordion {
  background-color: #eee;
  color: #444;
  cursor: pointer;
  padding: 18px;
  width: 100%;
  text-align: left;
  border: none;
  outline: none;
  transition: 0.4s;
}

/* Add a background color to the button if it is clicked on (add the .active class with JS), and when you move the mouse over it (hover) */
.accord .active, .accord .accordion:hover {
  background-color: #ccc;
}

/* Style the accordion panel. Note: hidden by default */
.accord .panel {
  padding: 0 18px;
  background-color: white;
  display: none;
  overflow: hidden;
}
</style>
<script type="text/javascript">
    var acc = document.getElementsByClassName("accordion");
var i;

for (i = 0; i < acc.length; i++) {
  acc[i].addEventListener("click", function() {
    /* Toggle between adding and removing the "active" class,
    to highlight the button that controls the panel */
    this.classList.toggle("active");

    /* Toggle between hiding and showing the active panel */
    var panel = this.nextElementSibling;
    if (panel.style.display === "block") {
      panel.style.display = "none";
    } else {
      panel.style.display = "block";
    }
  });
}
</script>
<!-- ======= Footer ======= -->
<?php include 'footer.php';?>
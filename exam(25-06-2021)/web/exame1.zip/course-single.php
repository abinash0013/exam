<?php include 'header.php';?>
<!--===================== End Header ===================-->
<section id="course-sg" style="background-image: url(assets/img/bank-po.jpg);" class="back-bg">
   
</section>

<!-- ==================== COURS content======================= -->
<section id="course-content">
  <div class="container">
      <div class="row">
           <div class="col-lg-8 col-md-8 col-sm-12">
               <div class="cour-left">
                   <h3>SSC CGL & CHSL</h3>
                   <p>Staff Selection Commission (SSC) is an organization under Government of India to recruit staff for various posts in the various Ministries and Departments of the Government of India and in Subordinate Offices. This commission is an attached office of the Department of Personnel and Training (DoPT) which consists of Chairman, two Members and a Secretary-cum-Controller of Examinations. This post is equivalent to the level of Additional Secretary to the Government of India.</p>
                  <p>The SSC Combined Graduate Level Examination for recruiting non-gazetted officers to various government jobs. its conduct exam every year.</p>
                  <ul>
                    <li><strong>CHSL</strong> (Combined Higher Secondary Level)</li>
                    <li><strong>LDC</strong> (Lower Division Clerk)</li>
                    <li><strong>MTS</strong> (Multi Tasking Staff)</li>
                  </ul>
                  <div class="cour-down">
                      <a class="" href="assets/img/ssc.pdf" targt="_blank"><i class="fa fa-download" aria-hidden="true"></i> Syllabus</a>

                      <a class="" href="assets/img/ssc.pdf" targt="_blank"><i class="fa fa-download" aria-hidden="true"></i> Exam Pattern</a>

                      <a class="" href="assets/img/ssc.pdf" targt="_blank"><i class="fas fa-shopping-cart"></i> Buy Now</a>

                  </div>
               </div>
           </div>
           <div class="col-lg-4 col-md-4 col-sm-12">
               <div class="cour-right">
                   <img src="assets/img/courses-ssc.png">
               </div>
           </div>
      </div>
  </div>
</section>
<!-- ========================our key ================================= -->
<section id="cour-mid">
    <div class="container">
        <div class="ssc-ma">
             <p><i class="fas fa-chevron-left"></i> SSC Exam</p>
             <h3>SSC Exams Subjects</h3>
        </div>

        <div class="ssc-ma">
             <div class="row">
                 <div class="col-lg-6 col-md-6 col-sm-12">
                     <div class="ssc-ma-one row">
                        <div class="ssc-img col-lg-2 col-md-2 col-sm-6">
                            <img src="assets/img/viicon.png">
                        </div>
                        <div class="ssc-con col-lg-10 col-md-10 col-sm-6">
                            <p>Access more than</p>
                            <h3>15,630+ courses for SSC Exams</h3>
                        </div>
                     </div>
                 </div>
                 <div class="col-lg-6 col-md-6 col-sm-12 ssc-ma-two">
                     
                        <a href="#">Get Subscribed</a>
                    
                 </div>
             </div>
        </div>


    </div>
</section>
<!-- =====================Courises=========================== -->
<section id="course-main">
  <div class="container">
       <div class="row">
           <div class="col-lg-4 col-md-4 col-sm-12 ">
              <div class="course-con1">
                  <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12">
                         <h3>General Awareness</h3>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 upcome">
                        <p>9 upcoming</p>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 colike">
                        <p>1K courses</p>
                      </div>
                  </div>
              </div>
           </div>

           <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="course-con1">
                  <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12">
                         <h3>General Awareness</h3>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 upcome">
                        <p>9 upcoming</p>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 colike">
                        <p>1K courses</p>
                      </div>
                  </div>
              </div>
           </div>

           <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="course-con1">
                  <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12">
                         <h3>General Awareness</h3>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 upcome">
                        <p>9 upcoming</p>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 colike">
                        <p>1K courses</p>
                      </div>
                  </div>
              </div>
           </div>


           <div class="col-lg-4 col-md-4 col-sm-12 before1">
              <div class="course-con1">
                  <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12">
                         <h3>General Awareness</h3>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 upcome">
                        <p>9 upcoming</p>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 colike">
                        <p>1K courses</p>
                      </div>
                  </div>
              </div>
           </div>

           <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="course-con1">
                  <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12">
                         <h3>General Awareness</h3>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 upcome">
                        <p>9 upcoming</p>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 colike">
                        <p>1K courses</p>
                      </div>
                  </div>
              </div>
           </div>

           <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="course-con1">
                  <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12">
                         <h3>General Awareness</h3>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 upcome">
                        <p>9 upcoming</p>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 colike">
                        <p>1K courses</p>
                      </div>
                  </div>
              </div>
           </div>



           <div class="col-lg-4 col-md-4 col-sm-12 before1">
              <div class="course-con1">
                  <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12">
                         <h3>General Awareness</h3>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 upcome">
                        <p>9 upcoming</p>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 colike">
                        <p>1K courses</p>
                      </div>
                  </div>
              </div>
           </div>

           <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="course-con1">
                  <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12">
                         <h3>General Awareness</h3>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 upcome">
                        <p>9 upcoming</p>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 colike">
                        <p>1K courses</p>
                      </div>
                  </div>
              </div>
           </div>

           <div class="col-lg-4 col-md-4 col-sm-12">
              <div class="course-con1">
                  <div class="row">
                      <div class="col-lg-12 col-md-12 col-sm-12">
                         <h3>General Awareness</h3>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 upcome">
                        <p>9 upcoming</p>
                      </div>
                      <div class="col-lg-6 col-md-6 col-sm-6 colike">
                        <p>1K courses</p>
                      </div>
                  </div>
              </div>
           </div>

       </div>
  </div>
</section>

<!--====================Exams Covered================================== -->
<section id="quiz">
  <div class="container">
     <div class="row quizes">
         <div class="col-lg-6 col-md-6 col-sm-6 quz-title">
           <h4>Quiz</h4>
         </div>
         <div class="col-lg-6 col-md-6 col-sm-6 quz-see">
           <h5><a href="#">See all</a></h5>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
             <div class="quz-main">
                <div class="quz-img">
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>

     </div>
  </div>
</section>
<!--=============our other ================================= -->

<section id="quiz">
  <div class="container">
     <div class="row quizes">
         <div class="col-lg-6 col-md-6 col-sm-6 quz-title">
           <h4>Notes & PDF’s</h4>
         </div>
         <div class="col-lg-6 col-md-6 col-sm-6 quz-see">
           <h5><a href="#">See all</a></h5>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
             <div class="quz-main">
                <div class="quz-img">
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>

     </div>
  </div>
</section>

<!-- ======================================= -->
<section id="quiz">
  <div class="container">
     <div class="row quizes">
         <div class="col-lg-6 col-md-6 col-sm-6 quz-title">
           <h4>Videos</h4>
         </div>
         <div class="col-lg-6 col-md-6 col-sm-6 quz-see">
           <h5><a href="#">See all</a></h5>
         </div>

         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
             <div class="quz-main">
                <div class="quz-img">
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>
         <div class="col-lg-4 col-md-4 col-sm-12">
            <div class="quz-main">
                <div class="quz-img" >
                  <img src="assets/img/quzimg.png">
                </div>
                 <div class="quz-con">
                    <h3>SSC GD Constable </h3>
                  <p>Complete Course on Quantitative Aptitude for SSC CGL - Part 1</p>
                  <p>Lesson 16</p>
                 </div>
            </div>
         </div>

     </div>
  </div>
</section>
<!-- ======= Footer ======= -->
<?php include 'footer.php';?>
<?php include 'header.php';?>

<!--===================== End Header ===================-->
<section id="log-in">
    <div class="container">
        <div class="log-main">
            <form action="/action_page.php" >
              <div class="login-con">
                <h1>Sign Up</h1>
               
                <hr>
                <label for="name"><b>Full Name </b></label>
                <input type="text" placeholder="Enter Full Name" name="name" required>

                <label for="email"><b>Email</b></label>
                <input type="text" placeholder="Enter Email" name="email" required>

                <label for="psw"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="psw" required>
                
                <label for="psw-repeat"><b>Repeat Password</b></label>
                <input type="password" placeholder="Repeat Password" name="psw-repeat" id="psw-repeat" required>

                <div class="clearfix">                 
                  <button type="submit" class="login">Sign Up</button>
                </div>
              </div>
            </form>
        </div>
    </div>
</section>

<!-- ==================== COURS content======================= -->

<!--=============our other ================================= -->



<!-- ======= Footer ======= -->
<?php include 'footer.php';?>
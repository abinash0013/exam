<?php include 'header.php';?>
<!--===================== End Header ===================-->
<section id="course-sg" style="background-image: url(assets/img/bank-po.jpg);" class="back-bg">

    <div class="container">
          <div class="contact-text">
               <h1>Contact Us</h1>
          </div>
         </div>
         <div class="over-contact"></div>
   
</section>

<!-- ==================== COURS content======================= -->



  <section id="adress-con">
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-sm-12">
                  <div class="addtes-text">
                    <i class="fa fa-map-marker" aria-hidden="true"></i>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
                  </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="phone-text">
                    <i class="fa fa-phone" aria-hidden="true"></i>
                                <a href="tel:" >+91 0123456789</a>
                                  
                </div>
            </div>
            <div class="col-md-4 col-sm-12">
                <div class="phone-text">
                   <i class="fa fa-envelope" aria-hidden="true"></i>
                   <a href="mailto:">test@gmail.com</a>
                 </div>
            </div>
        </div>
    </div>
  </section>
  
  

  <section id="contact-map">
    <div class="container">
        <div class="row">
        <div class="col-md-6 col-sm-12">
             <div class="contact-form-s">
                <form id="contact-form1" method="POST" action="mail.php">

                     <div class="form-mid-to">
                      <div class="form-mid-left">
                        <div class="form-group">
                <input id="form_name" type="text" name="name" class="form-control" placeholder="Full Name" required="required" data-error="Fullname is required." autocomplete="off">
                <div class="help-block with-errors"></div>
              </div>
                      </div>
                      
                     
                    </div>

                    <div class="form-mid-to">
                      <div class="form-mid-left">
                <div class="form-group">
                <input id="form_email" type="email" name="email" class="form-control" placeholder="Email" required="required" data-error="Email is required.">
                <div class="help-block with-errors"></div>
              </div>                                                        
                      </div>
                      </div>

                    <div class="form-mid-to">
                      <div class="form-mid-left">
                        <div class="form-group">  
                        <input id="form_name" type="tel" name="phonenumber" class="form-control" placeholder="Phone No" required="required" data-error="Phone no. is required." size="20" minlength="9" maxlength="14">
                <div class="help-block with-errors"></div>
              </div>   
                      </div>
                      
                      
                    </div>

                      
               

                    <div class="form-mid-to">
                      <div class="form-mid-left">
                        <div class="form-group">  
                         <textarea placeholder="Message" name="message"></textarea>
                        <div class="help-block with-errors"></div>
                      </div>   
                      </div>
                      
                      
                    </div>
           
          
          
              <input type="submit" class="btn btn-send" value="Submit">
             <div class="messages"></div>
                </form>

             </div>
        </div> 
        <div class="col-md-6 col-sm-12">
            <div class="map-cl">                
                <iframe src="https://www.google.com/maps/embed?pb=!1m19!1m8!1m3!1d113980.29145495666!2d75.7564525!3d26.7799639!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x396dc9f6e67b2e39%3A0xaf4cf1f8e4cc6168!2sRoyal%20Guest%20House!3m2!1d26.7799811!2d75.8264928!5e0!3m2!1sen!2sin!4v1617061733679!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
            </div>
        </div>  
        </div>      
    </div>
  </section>
  
 
<!-- =====================Courises=========================== -->

<!-- ========================our key ================================= -->

<!--====================Exams Covered================================== -->

<!--=============our other ================================= -->



<!-- ======= Footer ======= -->
<?php include 'footer.php';?>